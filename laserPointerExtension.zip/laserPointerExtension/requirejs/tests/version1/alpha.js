define("alpha",
  function() {
    return {
      version: 1
    };
  }
);
