define(function (require, exports, module) {
    if (module.exports) {
        module.exports = function () {
            return 'implicitModule';
        };
    }
});
