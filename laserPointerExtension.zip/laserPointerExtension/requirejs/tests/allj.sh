java -classpath ../../r.js/lib/rhino/js.jar:../../r.js/lib/closure.compiler.jar org.mozilla.javascript.tools.shell.Main ../../r.js/r.js all-server.js
