define(["require","exports","module","../2"], function (r, e, m, two) {
    return {
        name: 'b1',
        two: two
    };
})