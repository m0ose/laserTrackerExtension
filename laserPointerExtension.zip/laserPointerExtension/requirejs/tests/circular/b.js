define(['c', 'exports'], function (c, exports) {
    exports.name = 'b';
    exports.c = c;
});
