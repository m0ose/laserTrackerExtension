define(function (require) {
    return {
        name: 'a' 
    };
});
