define({
    name: 'another/c/dim'
});
