define(['./minor'], function (minor) {
    return {
        name: 'another/c',
        minorName: minor.name
    };
});
