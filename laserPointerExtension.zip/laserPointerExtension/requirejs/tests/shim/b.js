var B = {
    name: 'b',
    aValue: A.name,
    dValue: new D()
};
