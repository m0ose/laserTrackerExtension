(function (root) {
    root.A = {
        name: 'a'
    };
}(this));
