var e = {
    nested: {
        e: {
            name: 'e'
        }
    }
};
