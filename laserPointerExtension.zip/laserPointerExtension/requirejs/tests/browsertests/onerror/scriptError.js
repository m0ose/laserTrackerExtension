
if (true) {
    throw "scriptError throwing";
}
