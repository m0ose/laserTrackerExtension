if (typeof define !== 'function') { var define = window.badDefine; }

define("three.js script");
