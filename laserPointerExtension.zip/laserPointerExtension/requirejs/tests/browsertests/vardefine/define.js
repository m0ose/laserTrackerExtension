
function define(message) {
    log(message);
}


function badDefine(message) {
    log("BAD DEFINE! " + message);
}