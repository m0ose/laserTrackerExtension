loadScript("two.js");

one = {
    name: "one"
};

console.log("Two's name is: " + two.name);
