<?php
sleep(3);
?>

window.log("one.php script");
