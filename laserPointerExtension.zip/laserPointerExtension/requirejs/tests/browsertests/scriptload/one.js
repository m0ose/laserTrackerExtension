log("one.js script");
