define(function(require, exports, module) {   
   exports.f = function () { return "sub/b" }; 
});
