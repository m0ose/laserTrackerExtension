define({
    name: 'sparkplugs'
});