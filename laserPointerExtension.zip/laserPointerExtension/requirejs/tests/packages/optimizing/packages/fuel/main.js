define({
    name: 'fuel'
});
