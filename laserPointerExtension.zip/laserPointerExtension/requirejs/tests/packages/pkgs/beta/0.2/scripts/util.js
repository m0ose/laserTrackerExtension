define({
    name: 'beta/util'
});
