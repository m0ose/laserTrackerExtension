console.log("uploading page content!");

[document.body.innerText]