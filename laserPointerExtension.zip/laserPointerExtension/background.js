requirejs([ 'http://localhost:9091/acequia/acequia.js'], function(){ console.log("requirejs loaded some files")
    onTuio2Dcur({body:[30,60,45]})
})
$(document).ready( function(){
    var ac2 = createAcequiaConnection()
    ac2.initializeAcequiaSession()
    ac2.subscribeMessage( "/tuio/2Dcur/set", onTuio2Dcur)
});

var statBeam = null;
var onTuio2Dcur = function (msg) {
    var x2 = parseFloat(msg.body[1]) ;
    var y2 = parseFloat(msg.body[2]) ;

    if(!statBeam){
        statBeam = new statusBeam();
    }

    statBeam.move(x2 * document.width, y2 * document.height )
    // timeout = setTimeout(onTimeout, 200);
};

//window.addEventListener('message', function(ev) {
//   console.log(ev) ;
//});
function statusBeam(){

    var this2 = this;
    this.move = function(x,y){
        this.sendMessage({ type: "extension", x:x, y:y});
    }
    chrome.tabs.onActivated.addListener(function(changeInfo) {
        console.log('tabs changed')

        chrome.tabs.executeScript(null, { file: "statbox.js" }, function() { console.log('statbox loaded')})
        chrome.tabs.executeScript(null, { file: "syntheticEvents.js" }, function() { console.log('synthetic loaded')})

        chrome.tabs.getSelected(function(v){ this2.selected = v;  })
        chrome.tabs.executeScript(this2.selected.id, { code: "console.log('hello') " }, function() { console.log('cons')})

    })

    this.sendMessage = function(val){
        //statBeam.sendMessage({x:30,y:10,state:'DOWN', prog:1})

        if( this2.selected){
            chrome.tabs.executeScript(this2.selected.id, { code: "receiveMessage(" + JSON.stringify(val) +" )" }, function() { console.log('msg sent',val)})
        }
    }


    /* this.minDist = 40;
     this.timeout = 1000;
     this.idleTimeout = 1000000;
     this.initialX = 0;
     this.initialY = 0;
     this.lastTime = new Date().getTime();
     this.div = document.createElement('div')
     this.div.style.cssText = " position:absolute";
     this.div.id = "statusBeamDiv";
     this.progressBar = document.createElement('progress')
     this.progressBar.style.cssText = " border: 2px blue solid; border-radius: 6px";
     this.progressBar.max = 1;
     this.progressBar.value = 0;
     this.progressBar.id = "statusBeamBar";
     this.div.appendChild( this.progressBar);

     var states = {up:"UP", down:"down"}
     this.state = states.up;
     this.idleTimer = null;

     this.move=function(x,y){
     this.sendMessage({ type: "extension", x:x, y:y}, "*");

     var now  = new Date().getTime();
     var dt = now - this.lastTime;
     var tratio = dt/this.timeout;
     var dist =  Math.sqrt( Math.pow(x-this.initialX,2) +  Math.pow( y-this.initialY,2))
     //console.log(tratio, dist)
     if( this.idleTimer){ window.clearTimeout( this.idleTimer )}
     this.idleTimer =  window.setTimeout( this.idle.bind( this ), this.idleTimeout )

     if( this.state == states.down){
     this.progress(100)
     if( tratio > 0.2){//idle start long press over
     this.state = states.up
     this.lastTime = now
     }
     else{
     console.log("mouse move")
     this.sendMessage({ type: "extension", state:"DOWN" }, "*");
     }
     this.lastTime = now
     }
     else if(this.state == states.up){
     if( dist > this.minDist){
     //reset counter
     this.lastTime = now
     this.initialX = x;
     this.initialY = y;
     this.progress(0)
     }
     if( tratio > 1){//initial mouse click
     this.state = states.down;
     this.lastTime = now
     this.initialX = x;
     this.initialY = y;
     this.sendMessage({ type: "extension", state:"CLICK" }, "*");
     }
     else{
     this.progress( tratio)
     }
     }
     }


     this.progress = function(ratio){
     if( ratio > 1){
     this.sendMessage({ type: "extension", prog:ratio, invisible:false,state:"DOWN" }, "*");
     }
     else{
     this.sendMessage({ type: "extension", prog:ratio, invisible:false,state:"UP" }, "*");
     }
     return ratio
     }


     this.idle = function(){
     this.sendMessage({ type: "extension", invisible:true }, "*");
     }
     */

}
