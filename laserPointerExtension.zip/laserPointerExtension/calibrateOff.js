var identifier = document.getElementById("ck_identifier");
document.body.removeChild(identifier);